-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2024 at 06:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cart_details` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `user_id`, `cart_details`) VALUES
(15, 1, '9:1/'),
(16, 13, '10:1/9:1/-1:-1/'),
(24, 19, '9:1/10:2/'),
(25, 20, '9:2/10:3/'),
(29, 6, '');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'MOTHERBOARD'),
(4, 'MONITOR'),
(5, 'GRAPHIC CARDS'),
(6, 'PROCESSORS'),
(7, 'MEMORY (RAM)'),
(8, 'STORAGE & NAS'),
(9, 'COOLING AND LIGHTING'),
(10, 'POWER SUPPLY, UPS & SURGE PROTECTORS'),
(11, 'CASINGS'),
(12, 'KEYBOARDS & MICE');

-- --------------------------------------------------------

--
-- Table structure for table `manufacturer`
--

CREATE TABLE `manufacturer` (
  `manufacturer_id` int(11) NOT NULL,
  `manufacturer_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `manufacturer`
--

INSERT INTO `manufacturer` (`manufacturer_id`, `manufacturer_name`) VALUES
(1, 'Asus'),
(5, 'MSI'),
(6, 'GIGABYTE'),
(7, 'AMD'),
(8, 'Intel'),
(9, 'NZXT'),
(10, 'DELL'),
(11, 'Samsung'),
(13, 'CORSAIR'),
(14, 'G.SKILL'),
(15, 'SEASONIC'),
(16, 'COOLER MASTER'),
(17, 'KINGSTON'),
(18, 'LOGITECH'),
(21, 'ASUSTOR'),
(22, 'SEAGATE');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `user_id` int(255) NOT NULL,
  `cart_d` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`order_id`, `user_id`, `cart_d`, `status`) VALUES
(23, 6, '21:3/', 'delivered');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `specifications` varchar(3000) NOT NULL,
  `price` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `manufacturer_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `img_path` varchar(255) NOT NULL,
  `specs` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `description`, `specifications`, `price`, `category_id`, `manufacturer_id`, `quantity`, `img_path`, `specs`) VALUES
(21, 'AMD RYZEN 9 5950X', 'The AMD Ryzen 9 5950X is a powerful desktop processor with 16 cores and 32 threads.', '# of CPU Cores\n16\n# of Threads\n32\nBase Clock\n3.4GHz\nMax Boost Clock\nUp to 4.9GHz\nTotal L2 Cache\n8MB\nTotal L3 Cache\n64MB\nUnlocked', 105000, 6, 7, 17, '1742-20210201100428-1720-20210111130433-Untitled-1.png', '45,89'),
(22, 'INTEL CORE I7-12700 PROCESSOR', 'Upgrade your desktop with the Intel Core i7-12700, a powerful chip that delivers exceptional performance and software development.', 'Total Cores\r\n12\r\n\r\n# of Performance-cores\r\n8\r\n\r\n# of Efficient-cores\r\n4\r\n\r\nTotal Threads\r\n20\r\n\r\nMax Turbo Frequency\r\n4.90 GHz', 97000, 6, 8, 50, '1934-20220830075938-12700 (1).png', '44,50'),
(25, 'AMD RYZEN 7 7700X', 'AMD Ryzen 7 7700X is a dominant gaming desktop processor that comes with 8 CPU cores 16 threads and a max boost clock speed of up to 54GHz', 'Architecture\r\nZen 4\r\n of CPU Cores\r\n8\r\nMultithreading SMT\r\nYes\r\n of Threads\r\n16\r\nMax Boost Clock\r\nUp to 54GHz\r\nBase Clock\r\n45GHz', 130000, 6, 7, 25, '1839-20221006124741-1536834-amd-ryzen-7-7000-series-PIB-angle-1260x709.png', '46,48'),
(26, 'INTEL CORE I5 PROCESSOR 14600K', 'The Intel Core i514600K is nearindistinguishable from the Core i513600K in benchmark results Its a fineperforming processor in its price class', 'otal Cores 14   of Performancecores 6   of Efficientcores 8  Total Threads 20  Max Turbo Frequency 53 GHz', 90000, 6, 8, 15, '2394-20231018174238-14600k.png', '50'),
(27, 'ASUS PRIME B550 PLUS', 'Powered by 3rd Gen AMD Ryzen processors the ASUS Prime B550PLUS delivers nextgeneration speeds with PCIe 4 0 and 1Gb LAN Boasting a robust power design comprehensive cooling solutions and intelligent tuning options the ASUS Prime B550PLUS provides mainstream users and DIY PC builders with a perfect allaround foundation via intuitive software and firmware features Free 3months Adobe Creative Cloud Subscription Receive complimentary access with the purchase of this product offer valid from 9152021 to 9152022 visit httpswwwasuscomuscontentasusoffersadobecreativecloud to clai', 'AMD AM4 Socket and PCIe 4 0 The perfect pairing for Zen 3 Ryzen 5000 and 3rd Gen AMD Ryzen CPUs\r\nUltrafast Connectivity 1x PCIe4 0 x16 SafeSlot 1Gb LAN dual M 2 slots NVMe SSDone with PCIe 4 0 x4 connectivity USB 3 2 Gen 2 TypeA  HDMI 2 1 4K60HZ DisPlay port 1 2 and Thunderbolt 3 header', 55000, 1, 1, 40, '1530-20200910184120-PRIME-B550-PLUS-with-box.png', '2,6'),
(28, 'ASUS TUF GAMING X570- PRO WIFI II', 'ASUS TUF GAMING X570PRO WIFI II takes all the essential elements of the latest AMD processors and combines them with gameready features and proven durability Engineered with militarygrade components an upgraded power solution and a comprehensive cooling system this motherboard offers rocksolid stable performance for marathon gaming Aesthetically TUF GAMING X570PRO WIFI II sports the new TUF GAMING logo and incorporates simple geometric design elements to reflect the dependability that defines the TUF GAMING series', 'CPU\r\nAMD Ryzen 5000 Series 5000 GSeries 4000 GSeries 3000 Series 3000 GSeries 2000 Series 2000 GSeries Desktop Processors\r\nChipset\r\nX570\r\nMemory\r\n\r\n4 x DIMM Max 128GB DDR4', 90000, 1, 1, 30, '2003-20230614113446-x570.png', '2,9'),
(29, 'MSI PRO B660M-E', 'MSI PRO B660ME DDR4 Motherboard\r\n helps users work smarter by delivering an efficient and productive experience Featuring stable functionality and highquality assembly\r\nPRO series motherboards provide not only optimized professional workflows but also less troubleshooting and longevity', 'CPU Support Supports 12th Gen Intel\r\nCore\r\nProcessors Pentium\r\nGold\r\nand Celeron\r\nProcessors\r\nCPU Socket LGA 1700\r\nChipset Intel\r\nB660 Chipset\r\nGraphics\r\nInterface\r\n1x PCIe 40 x16 slot\r\nDisplay Interface Support 4K60Hz as specified in HDMI 21 VGA  Requires\r\nProcessor Graphics\r\nMemory Support 2 DIMMs Dual Channel DDR44600 MHz OC\r\nExpansion Slots 1x PCIe 30 x1 slot\r\nStorage 1x M2 Gen3 x4 32Gbps slot\r\n4x SATA 6Gbps ports\r\nUSB ports 4x USB 32 Gen 1 5Gbps 4 TypeA\r\n6x USB 20\r\nLAN Intel\r\nI219V 1G LAN\r\nAudio 8Channel71 HD Audio with Audio Boost', 50000, 1, 5, 50, '2263-20220514120956-product_16412869646176c6e905cf8b379a75ebd2c77cfa1e.png', '5,11'),
(30, 'CORSAIR VENGEANCE 16GB', 'CORSAIR VENGEANCE DDR5 optimized for Intel motherboards delivers higher frequencies and greater capacities of DDR5 technology in a highquality compact module that suits your system', 'Memory Compatibility\r\nIntel 600 SeriesIntel 700 Series\r\nMemory Detail Compatibility\r\nIntel 600 SeriesIntel 700 Series\r\nHeat Spreader\r\nAluminum\r\nMemory Series\r\nVENGEANCE DDR5\r\nMemory Size\r\n16GB\r\nMemory Type\r\nDDR5\r\nPackage Memory Format\r\nDIMM', 20000, 7, 13, 50, '1374-20230824142633-VENGEANCE SINGLE RAM STICK DDR5.png', '51,55,57'),
(32, 'G.SKILL TRIDENTZ RGB SERIES 8GB', 'Featuring the awardwinning Trident Z heatspreader design the Trident Z RGB memory series combines vivid RGB lighting with awesome DDR4 DRAM performance', 'Memory Type\r\nDDR4\r\nCapacity\r\n8GB\r\nMultiChannel Kit\r\nDual Channel Kit\r\nTested Speed XMPEXPO\r\n3200 MTs', 30000, 7, 14, 40, '1748-20230318133559-G.SKILL TridentZ RGB Series  DDR4.png', '51,53,56'),
(33, 'CORSAIR VENGEANCE 16GB', 'Give your DDR4 laptop ultrafast SODIMM DRAM memory performance SODIMM DDR4 RAM modules are compatible with a wide range of Intel and AMD laptops and PCs', 'Memory Series\r\nVENGEANCE SODIMM\r\nMemory Size\r\n16GB 1 x 16GB\r\nMemory Type\r\nDDR4\r\nPackage Memory Format\r\nSODIMM\r\nPackage Memory Pin\r\n260\r\nSPD Latency\r\n22222253\r\nSPD Speed\r\n3200', 12000, 7, 13, 20, '1692-20240123112452-96598786-25d4-42ee-b614-009a363b896f_1_1687891727.png', '52,53,57'),
(34, 'GIGABYTE RTX 4060 WINDFORCE', 'Gigabyte GeForce RTX 4060 WindForce OC is a customdesign graphics card based on NVIDIAs latest mainstream GPU The WindForce OC is priced at the NVIDIA MSRP and to sweeten the deal the company has included a slight factoryoverclock for its GPU The Gigabyte WindForce is for those that just want to buy into the performance and features the RTX 4060 brings to the table and dont care too much about the cards aestheticssomething to install and forget about to get gaming Helping things are the cards extremely compact dimensions which should make it a good fit for SFF cases and externalGPU enclosures', 'Graphics Processing\r\nGeForce RTX 4060\r\nCore Clock\r\n2475 MHz Reference card 2460 MHz\r\nCUDA Cores\r\n3072\r\nMemory Clock\r\n17 Gbps\r\nMemory Size\r\n8 GB\r\nMemory Type\r\nGDDR6\r\nMemory Bus\r\n128 bit', 140000, 5, 6, 10, '1582-20240114042623-4060.png', '31,39'),
(35, 'ASUS ROG STRIX GEFORCE RTX 4080', 'The ASUS ROG Strix RTX 4080 OC is a highend graphics card capable of unleashing the full grunt of the GeForce RTX 4080 GPU It is currentgen 4K gaming ready', 'Graphic Engine\r\nNVIDIA GeForce RTX 4080\r\nBus Standard\r\nPCI Express 40\r\nOpenGL\r\nOpenGL46\r\nVideo Memory\r\n16GB GDDR6X\r\nEngine Clock\r\nOC mode 2535 MHz\r\nDefault mode 2505 MHz Boost Clock\r\nCUDA Core\r\n9728\r\nMemory Speed\r\n224 Gbps', 600000, 5, 1, 20, '1242-20230320055632-h732 (12).png', '32,41'),
(36, 'ASUS STRIX GAMING GEFORCE RTX 4070 TI', 'ROG Strix GeForce RTX 4070 Ti 12GB GDDR6X OC Edition with DLSS 3 and charttopping thermal performance\r\nPowered by NVIDIA DLSS3 ultraefficient Ada Lovelace arch and full ray tracing', 'Graphic Engine\r\nNVIDIA GeForce RTX 4070 Ti\r\nBus Standard\r\nPCI Express 40\r\nOpenGL\r\nOpenGL46\r\nVideo Memory\r\n12GB GDDR6X\r\nEngine Clock\r\nOC mode 2640 MHz\r\nDefault mode 2610 MHz Boost clock\r\nCUDA Core\r\n7680\r\nMemory Speed\r\n21 Gbps', 400000, 5, 1, 10, '978-20230425093455-h732 (3).png', '33,40'),
(37, 'MSI GEFORCE RTX 4070 TI SUPER', 'Get equipped for supercharged gaming and creating with NVIDIA GeForce RTX 4070 Ti SUPER Its built with the ultraefficient NVIDIA Ada Lovelace architecture Experience super fast ray tracing AIaccelerated performance with DLSS 3 new ways to create and much more', 'Boost Clock  Memory Speed\r\n2610 MHz  21 Gbps\r\n16GB GDDR6X\r\nDisplayPort x 3 v14a\r\nHDMI x 1 Supports 4K120Hz HDR 8K60Hz HDR and Variable Refresh Rate as specified in HDMI 21a\r\nTRI FROZR 3 Thermal Design\r\nTORX Fan 50 Fan blades linked by ring arcs and a fan cowl work together to stabilize and maintain highpressure airflow', 450000, 5, 5, 5, '2117-20240123085928-1024 (7).png', '33,41'),
(38, 'ASUS ROG THOR 1600W TITANIUM', 'Fueled by Gallium Nitride transistors digital control and lowESR capacitors the ROG Thor 1600W Titanium is the ultimate PSU for monstrous rigs', 'Dimensions\r\n190 x 150 x 86 mm\r\nEfficiency\r\n80Plus Titanium\r\nProtection Features\r\nOPPOVPUVPSCPOCPOTP\r\nHazardous Materials\r\nROHS\r\nAC Input Range\r\n100240Vac\r\nThermal Features\r\nROG Thermal Solution\r\nDC Output Voltage\r\n33V 5V 12V 12V 5Vsb\r\nMaximum Load\r\n20A 20A 1333A 03A 3A\r\nCombined Load\r\n100W 100W 1600W 36W 15W\r\nTotal Output\r\n1600W 115V240V 1300W 100V115V', 250000, 10, 1, 10, '128-20231120032006-h732 (5).png', '76'),
(39, 'MSI MAG A750GL PCIE5', 'The MAG A750GL PCIE5 power supply is designed to be ready for GeForce RTX TM 4070 Ti and other graphics cards thanks to its ATX 30 and PCIe 50 support', 'Efficiency Rating 80 PLUS Gold up to 90\r\nModular Yes full modular\r\nFan Size 120 mm\r\nFan Bearing Fluid Dynamic Bearing\r\nDimensions DxWxH 140 x 150 x 86 mm\r\nPFC Type Active PFC\r\nInput Voltage Range 100240 VAC\r\nPower Watt 750W\r\nPower Excursion 1500W up to 200 of the PSUs rated power for\r\n100s', 35000, 10, 5, 10, '2400-20231220071354-1024 (2).png', '72'),
(41, 'SEASONIC S12 Series S12III 750W', 'The Seasonic S12III Series 750W 80 Plus Bronze ATX Power Supply is an efficient and durable unit designed to deliver consistent power to your system Instead of removable modular cables this power supply has all of the cables and its connectors builtin As for cooling its equipped with a 120mm fan which works with the SFC intelligent thermal circuit feature to balance noise and cooling performance All the standard cables youll need in a build are included such as the motherboard CPU PCIe SATA and 4pin Molexperipheral cables', 'ATX 12 V\r\nFixed cables\r\n80 PLUS Bronze Certified\r\n3 Years Warranty\r\nDimensions 140 mm L x 150 mm W x 86 mm H', 15000, 10, 15, 30, '1982-20240329093434-connector-plate-angled.png', '72'),
(42, 'NZXT F140 RGB DUO 140MM', 'The RGB Duo Fans strike a balance between bright style and performance with twenty individually addressable RGBs and high static pressureAlso Enjoy vibrant RGB lighting from all angles with 20 individually addressable LEDs\r\nFan blade design deliver the optimal balance between airflow and high static', '140mm RGB DUO Fan\r\n2\r\n\r\nRGB Controller\r\n1\r\n\r\nInstallation Accessories\r\n1\r\n\r\nKEY SPECS\r\n\r\nMaterialPlastic rubber PCB\r\n\r\nFan Rated Voltage12V DC 026A 312W\r\n\r\nLED Quantity20\r\n\r\nBearingFluid Dynamic Bearing FDB\r\n\r\nFan Connector4pin PWM\r\n\r\nDIMENSIONS\r\n\r\nHeight140mm\r\n\r\nWidth140mm\r\n\r\nDepth25mm\r\n\r\nCOOLING\r\n\r\nSpeed500  1800  300RPM\r\n\r\nAirflow8475 CFM\r\n\r\nStatic Pressure272 mmHO\r\n', 28500, 9, 9, 50, '2024-20230614161004-1673293216-f140-rgb-duo-twin-pack-with-rgb-controller-left-side-angle-view-white.png', '67'),
(43, 'ASUS ROG RYUO III 360 ARGB', 'ROG Ryuo III 360 allinone liquid CPU cooler with Asetek 8th gen pump solution Anime Matrix LED Display and ROG ARGB cooling fansAlso the latest 8th gen Asetek pump is armed with a 3phase motor that delivers ultimate cooling performance with higher flow and lower impedance', '\r\nProduct Dimensions	1677L x 827W x 512H\r\nBrand	ASUS\r\nVoltage	12 Volts\r\nWattage	12 watts\r\nCooling Method	Fan\r\nCompatible Devices	Radiator\r\nNoise Level	3645 dB\r\nMaterial	Aluminum\r\nMaximum Rotational Speed	1600 RPM', 100000, 9, 1, 20, '1538-20230324105458-h732 (1).png', '69'),
(44, 'NZXT T120 RGB CPU AIR COOLER', 'The T120 is a direct mounted highperformance air cooler Its as cool as it is coollooking thanks to a sleek aluminum heat pipe cover It provides excellent thermal performance in a small package', 'Aluminum heat pipe cover discreetly hides copper piping\r\n4 conductive copper heat pipes with Direct Contact technology allow for maximum thermal transfer from CPU to cooler\r\nProvides high static pressure moving ample air through the radiator for excellent cooling with some RGB flair\r\nIncludes retention brackets and mounting accessories for both Intel and AMD motherboards\r\nSlim radiator footprint allows plenty of space for an additional fan to further accelerate exhaust out the back of the PC\r\nCustomizable RGB lighting through NZXT CAM with RGB  Fan Controller Controller not included\r\nIncludes 1 gram of NZXT HighPerformance Thermal Paste\r\nWont block RAM or GPU slots for most cases', 26000, 9, 9, 50, '937-20230614160859-1666391726-t120-rgb-hero-black.png', '68'),
(45, 'KINGSTON NV2 500GB NVME SSD', 'Kingstons NV2 PCIe 40 NVMe SSD is a substantial nextgen storage solution powered by a Gen 44 NVMe controller NV2 delivers readwrite speeds of up to 35002800MBs 1 with lower power requirements and lower heat to help optimise your systems performance and deliver value without sacrifice', 'Form Factor M2 2280\r\nCapacity 500GB\r\nInterface PCIe 40 x4 NVMe\r\nPerformance\r\nMax Sequential Read Up to 3500 MBps\r\nMax Sequential Write Up to 2100 MBps\r\nDimensions  Weight\r\nHeight 380mm\r\nWeight 10g', 16000, 8, 17, 30, '1327-20231229111739-nv2.png', '60,62,64'),
(46, 'SAMSUNG 990 PRO SSD 2TB', ' Designed for tech enthusiasts hardcore gamers and heavyworkload professionals who want blazing fast speed\r\n\r\n Enjoy up to 50 improved performance per watt over 980 PRO plus optimal power efficiency with max PCIe 40 performance', 'Capacity\r\n2000GB 1GB1 Billion byte by IDEMA  Actual usable capacity may be less due to formatting partitioning operating system applications or otherwise\r\n\r\nInterface\r\nPCIe Gen 40 x4 NVMe 20\r\n\r\nDimension WxHxD\r\n\r\n80 x 22 x 23 mm\r\n\r\nWeight\r\n\r\nMax 90g Weight\r\n\r\nStorage Memory\r\n\r\nSamsung VNAND 3bit MLC\r\n\r\nController\r\nSamsung 2GB Low Power DDR4 SDRAM\r\n\r\nPerformance\r\nRandom Read 4KB QD32\r\n\r\nUp to 1400000 IOPS  Performance may vary based on system hardware  configuration', 70000, 8, 11, 10, '401-20230107072258-990.png', '60,62,66'),
(47, 'SAMSUNG 870 EVO 500GB', 'The 870 EVO achieves the maximum SATA interface limit of 560530 MBs sequential speeds Everyday users can now enjoy professionallevel SSD performance', 'Form Factor 25\r\nCapacity 500GB\r\nMemory Components 3D NAND\r\nInterface SATA III\r\nCache 512MB\r\nPerformance\r\nMax Sequential Read Up to 560 MBps\r\nMax Sequential Write Up to 530 MBps\r\nMTBF 1500000 hours\r\nEnvironmental\r\nPower Consumption Idle Max 30 mW\r\nPower Consumption Active Average 22WMaximum 35W\r\nMax Shock Resistance 1500G\r\nDimensions  Weight\r\nHeight 700mm\r\nWidth 6985mm\r\nDepth 10000mm\r\nWeight 8618g', 20000, 8, 11, 20, '667-20210201095939-Untitled-4.png', '59,63,64'),
(48, 'NZXT H7 ELITE CASE', 'This midtower case is the premier choice for enthusiasts featuring a tempered glass front panel to show off three preinstalled 140mm RGB Fans a builtin RGB  Fan Controller widened channels hooks straps and toolless entry\r\n', 'Perforated top panel\r\nIntuitive cable management system with wide channels hooks  straps\r\nToolless access to front  side panels tinted panels on black variant only to front  side panels\r\nFront  top support radiators up to 360mm\r\nThree preinstalled RGB 140mm Fans\r\nOne preinstalled 140mm Quiet Airflow Fan\r\nSupports vertical GPU mounting Sold Separately\r\nBuiltin RGB  Fan Controller V2 w NZXT CAM\r\nTempered glass front panel\r\nTwo topmounted USB 32 TypeA ports\r\nOne topmounted USB 32 TypeC port\r\nTwo color options Matte Black Matte White', 56000, 11, 9, 50, '1415-20231219114031-1680241561-h7-elite-rgb-black-system (1).png', ''),
(49, 'NZXT H6 FLOW CASE', 'Experience peak performance within an innovative compact dualchamber Prioritizing GPU cooling the H6 Flows panoramic glass showcases the interior while freeing up space for improved airflow', 'Wraparound glass panels with a seamless edge provides an unobstructed view of the inside to highlight key components\r\nCompact dualchamber design improves overall thermal performance and creates a clean uncrowded aesthetic\r\nIncludes three preinstalled 120mm fans positioned at an ideal angle for superb outofthebox cooling\r\nThe top and side panels feature an airflowoptimized perforation pattern to enhance overall performance and filter dust\r\nAn intuitive cable management system simplifies the build process by using wide channels and straps\r\nToolfree access to the top and side panels makes upgrading quick and convenient\r\nTop panel supports radiators up to 360mm in length Up to 365mm GPU and 200mm PSU clearance', 30000, 11, 9, 50, '2207-20231127114237-1698159864-h6-flow-hero-white.png', ''),
(50, 'GIGABYTE C301 CASE', 'The GIGABYTE C301 GLASS V2 comes with the large mesh front and the vented top panel delivering generous airflow for optimized cooling with premium aestheticsit have The builtin ARGB connector hub is equipped with six 5V 3pin connectors enabling users to expand their RGB light stripes create a superb cooling system', 'Optimized Airflow Design\r\nRGB Fusion with ARGB Connector Hub\r\nSupport Motherboards up to EATX\r\nUp to 360mm Liquid Cooling Compatible\r\nSupport Vertical GPU Installation\r\nFullSize Tempered Glass Side Panel\r\nWith USB 30 x2 and USB 31 TypeC x1 on IO panel\r\nPreinstalled 4 ARGB fans', 30000, 11, 6, 10, '1515-20230912141606-kfimg (2).png', ''),
(53, 'COOLER MASTER TD500 MESH CASE', 'The MasterBox TD500 Mesh  MasterBox TD500 Mesh White embody airflow performance in an art form Three preinstalled ARGB fans flood the system with airflow and lighting demonstrating the unique effect of ARGB through the Crystalline Tempered Glass\r\n\r\nEach element of design is precisionengineered to maximize performance  quality alongside aesthetics evolving beyond the current limits of lighting and cooling With advanced technology sculpted into fine art the MasterBox TD500 Mesh  Mesh White carve their own path to the bleeding edge', 'Colors Black\r\nMaterials  Exterior Steel Mesh Plastic\r\nMaterials  Left Side Panel Tempered Glass\r\nDimensions L x W x H 493 x 217 x 469mm incl Protrusions 4295 x 205x 447mm excl Protrusions\r\nVolume 4014L excl Protrusions\r\nMotherboard Support Mini ITX Micro ATX ATX SSI CEB EATX up to 12 x 107 motherboards\r\nExpansion Slots 7\r\n525 Drive Bays NA\r\n25  35 Drive Bays Combo 2\r\n25 Drive Bays 4 22 combo\r\nIO Panel 2 x USB 32 Gen 1 USB 30 1x 35mm Audio Jack 1x 35mm Mic Jack 1x ARGB Hub 1x ARGB 1to3 Splitter\r\nPreinstalled Fans  Top NA\r\nPreinstalled Fans  Front 3x 120mm CF120 ARGB\r\nPreinstalled Fans  Rear NA\r\nFan Support  Top 3x 120mm 2x 140mm\r\nFan Support  Front 3x 120mm 2x 140mm\r\nFan Support  Rear 1x 120mm\r\nRadiator Support  Top 120mm 240mm 360mm 44mm max motherboard component height\r\nRadiator Support  Front 120mm 140mm 240mm 280mm 360mm\r\nRadiator Support  Rear 120mm\r\nClearance  CPU Cooler 165mm649\r\nClearance  PSU 180mm708 295mm1161 w HDD cage removed\r\nClearance  GFX 410mm161\r\nCable Routing 19mm074\r\nDust Filters Front Top Bottom\r\nPower Supply Support Bottom Mount ATX', 30000, 11, 16, 50, '938-20240304122047-td500-mesh-v2-black-gallery-2-0110-zoom.png', ''),
(54, 'ASUS ROG Z11 MINI-ITX/DTX', 'ROG Z11 is a premium MiniITXDTX case with a sleek and stylish look that rises above the competition by empowering users to showcase compact builds without compromise Each feature has been designed conscientiously with the user in mind to maximize utility flexibility and connectivity The patented 11 tilt design provides optimized airflow and heat dissipation to create an innovative solution that maximizes thermal performance with demanding hardwaresuch as an ATX power supply or a 3slot graphics card without a riser cable For fans of water cooling Z11 offers ample space and the option of a custom liquid cooling loop Adding style to substance internal build components are beautifully illuminated by Aura Sync lighting that can be seen through the front and rightside 4 mm gray tempered glass panels\r\n', 'Case Size\r\nMini Tower\r\nMotherboard Support\r\nMiniITX\r\nMiniDTX\r\nDrive Bays\r\n4 x 25 Bay\r\n1 x 2535 Combo Bay\r\nExpansion Slots\r\n3 expansion slots space\r\nFront IO Port\r\n2 x USB 32 Gen1\r\n1 x USB 32 Gen2 Type C\r\n2 x USB 20\r\nTempered Glass\r\nFront Side\r\nRight Side\r\nRadiator Support Rear\r\n120 mm\r\n240 mm\r\nCooling Support Top\r\n2 x 120 mm\r\n2 x 140 mm\r\nCooling Support Rear\r\n2 x 120 mm\r\nMaximum CPU Cooler Height\r\n130 mm\r\nMaximum GPU Length\r\n320 mm\r\nMaximum PSU Length\r\n160 mm ATX or SFX\r\nRemovable Dust Filters', 50000, 11, 1, 20, '1938-2239-1938-20210510145631-ROG Z11-3D-2.png', ''),
(55, 'ASUS ROG STRIX XG32VQR', '32 WQHD 2560 X 1440 1800R curved HDR gaming monitor with 144Hz refresh rate for supersmooth gaming visuals\r\nHigh Dynamic Range HDR technology with DCIP3 94 professional color gamut delivers contrast and color performance that meets DisplayHDR 400 certification\r\nRadeon FreeSync 2 HDR technology provides butterysmooth gameplay low latency and better brightness and contrast\r\nShadow Boost enhances image details in dark areas brightening scenes without overexposing bright areas\r\nMultiple HDR modes allow users to adjust settings based on usage such as gaming content creation or video display', 'isplay\r\nPanel Size inch \r\n315\r\nCurvature \r\n1800R\r\nAspect Ratio \r\n169\r\nColor Space sRGB \r\n125\r\nPanel Type \r\nVA\r\nTrue Resolution \r\n2560x1440\r\nDisplay Viewing Area HxV \r\n697344 x 392256 mm\r\nDisplay Surface \r\nNonGlare\r\nPixel Pitch \r\n0272mm\r\nBrightness Typ \r\n450cd', 200000, 4, 1, 20, '2050-20240305044111-h525.png', '15,19,20,30'),
(56, 'ASUS TUF GAMING VG328QA1A', '315inch Full HD 1920 x 1080 gaming monitor with overclock to 170Hz refresh rate designed for professional gamers and immersive gameplay', 'Model\r\nTUF Gaming VG328QA1A\r\nDisplay\r\nPanel Size inch  315\r\nAspect Ratio  169\r\nDisplay Viewing Area H x V  6984 x 39285 mm\r\nDisplay Surface  NonGlare\r\nBacklight Type  LED\r\nPanel Type  VA\r\nViewing Angle CR10 HV  178 178\r\nPixel Pitch  0363mm\r\nResolution  1920x1080\r\nColor Space sRGB  100\r\nBrightness Typ  300cd\r\nContrast Ratio Typ  30001\r\nDisplay Colors  167M\r\nResponse Time  1ms MPRT\r\nRefresh Rate Max  170Hz', 100000, 4, 1, 10, '2296-20231004083447-vg32.png', '14,20,90'),
(57, 'CORSAIR XENEON 27QHD240 OLED', 'Elevate your gaming performance with the impressive 240Hz refresh rate of the Corsair Xeneon 27QHD240\r\nEnjoy smoother tearfree gameplay that allows you to react faster and make precise movements', 'Native Resolution\r\n2560x1440 169\r\nHDR Certification\r\nNone\r\nAC Adapter\r\n180W\r\nDisplay Technology\r\nOLED\r\nFlicker Free\r\nYes\r\nDisplay Inputs\r\n2x HDMI 21 1x DisplayPort 14 1x TypeC DP AltMode\r\nDisplay Surface\r\nNonGlare\r\nDisplay Colors\r\n107B 10bit RGB', 450000, 4, 13, 5, '2129-20230808145148-CM-9030002_01.png', '16,18,21,91'),
(58, 'Dell 27 4K P2721Q ', 'Detail driven Capture every nuance on a brilliant 27inch 6858 mm 4K monitor with more than 8 million pixels and four times the resolution of standard Monitor', 'Display\r\nDiagonal Viewing Size 68466 mm 2696 in\r\n\r\nPreset Display Area H x V\r\n596 74 mm x 33566 mm\r\n2349 in x 1321 in\r\n20030175 mm 31030 in\r\n\r\nPanel Type\r\nInPlane switching Technology\r\n\r\nDisplay Screen Coating\r\nAntiglare with 3H hardness\r\n\r\nMaximum Preset Resolution\r\n3840 x 2160 at 60Hz\r\n\r\nBorder Width Edge of Monitor active area\r\n74 mm Top\r\n74 mm LeftRight\r\n177 mm Bottom\r\n\r\nViewing Angle\r\n178 vertical typical\r\n178 horizontal typical\r\n\r\nPixel Pitch\r\n01554 mm x 01554 mm\r\n\r\nPixel Per Inch PPI\r\n163\r\n\r\nContrast Ratio\r\n1000 1 typical\r\n\r\nAspect Ratio\r\n1609', 150000, 4, 10, 10, '4-600x600.jpg', '16,18,20,27'),
(59, 'Samsung C49RG9 ', 'Built to deliver a wide and immersive gaming experience the C49RG9 49 329 120 Hz Curved FreeSync HDR VA Gaming Monitor from Samsung features a 49 Vertical Alignment VA panel with a native resolution of 5120 x 1440 a 329 aspect ratio an 1800R curvature rating a 120 Hz refresh rate DisplayHDR 1000 with a peak luminance of 1000 cdm2 AMD FreeSync II and QLED backlighting', '49 Vertical Alignment VA Panel\r\n1 x HDMI 20  2 x DisplayPort 14\r\n5120 x 1440 Resolution\r\n30001 Contrast Ratio', 300000, 4, 11, 5, 'C49RG9_003_Front2_Black.webp', '15,92,20,29'),
(60, 'ASUSTOR DRIVESTOR 2 (AS1102T) ', ' the Asustor Drivestor 2 NAS is a modest system that for the most part does not overpromise in what it can provide Its architecture lends quite well to the more budgetfriendly buyer home users and those that are simply looking for an easy backup option to the cloud Additionally less demanding users who want some light multimedia support networkbased camera surveillance and crossplatform file sharing will certainly see plenty of use in the Drivestor 2 device', 'Realtek RTD1296 QuadCore 14 GHz CPU\r\nUses 1 GB DDR4  40 more efficient\r\nSuperfast 25Gigabit Ethernet\r\nEnjoy download upload and stream content with 4K transcoding\r\nSupports Wake on LAN and Wake on WAN\r\nNew Rose Gold logo\r\nToolfree installation', 120000, 8, 21, 5, '2260-20240305032730-banner_model.png', '61,63'),
(61, 'SEAGATE BARRACUDA 2TB ST2000DM008', 'Versatile and dependable the fierce Seagate BarraCuda drives build upon a reliable drive family spanning 20 years Count on affordable BarraCuda drives as 25 and 35 inch HDD solutions for nearly any applicationworking playing and storing your movies and music', 'SATA 60Gbs\r\nCapacity\r\n2TB\r\nRPM\r\n7200 RPM\r\nCache\r\n256MB\r\n', 20000, 8, 22, 20, '949-20190109153939-238-20180920141248-2tb.png', '59,63,66'),
(62, 'LOGITECH WIRELESS MOUSE M275', 'A new generation of LIGHTSPEED wireless technology is now available to provide players with a great wireless gaming experience The M275 LIGHTSPEED wireless gaming mouse is designed to deliver outstanding gaming performance at a higher priceperformance and innovative technology', 'Comfortable righthand contoured mouse\r\nLogitech Advanced Optical Sensor\r\nWide scroll wheel\r\nHardware Platform Pc\r\n3 Months Warranty', 6000, 12, 18, 100, '1758-20240325151550-02-28.png', '71'),
(63, 'ROG GLADIUS II CORE', 'Classic ROG Gladius ergonomics with discrete left and right buttons lightweight design and durable nonslip side grips etched with the iconic ROG totem\r\nGaminggrade PAW3327 optical sensor with up to 6200 DPI for fast accurate tracking', 'Connectivity	  	USB 20 TypeC to TypeA\r\nSensor	  	PMW 3327\r\nResolution	  	2006200\r\nUSB Report rate	  	1000 Hz\r\nButton	  	6 programmable buttons\r\nCable	  	1 x 2meter braided USB cable  ', 15000, 12, 1, 50, '1640-20231202125130-gladias ii core.png', '70'),
(64, 'LOGITECH G512 CARBON MECHANICAL KEYBOARD', 'G512 is a highperformance gaming keyboard featuring your choice of advanced GX mechanical switches Advanced gaming technology and aluminumalloy construction make G512 simple durable and fullfeatured', 'Length 132 mm\r\nWidth 445 mm\r\nHeight 34 mm\r\nWeight wo cable 1150 g\r\nCable Length 6 ft\r\nG512 GX BLUE\r\nLength 132 mm\r\nWidth 445 mm\r\nHeight 355 mm\r\nWeight wo cable 1130 g\r\nCable Length 6 ft\r\nROMERG TACTILELINEAR MECHANICAL SWITCHES\r\nDurability 70 million keypresses\r\nActuation distance 15 mm\r\nActuation force 45 g\r\nTotal travel distance 32 mm\r\nGX BLUE MECHANICAL SWITCHES\r\nDurability 70 million keypresses\r\nActuation distance 19 mm\r\nActuation force 50 g\r\nTotal travel distance 40 mm\r\nConnection Type USB 20\r\nUSB Protocol USB 20\r\nUSB Ports Builtin Yes 20\r\nIndicator LIghts LED 2\r\nBacklighting Yes RGB per key lighting\r\nSPECIAL KEYS\r\nLighting Controls FNF5F6F7\r\nGame Mode FNF8\r\nMedia Controls FNF9F10F11F12\r\nVolume Contros FN PRTSCSCRLKPAUSE\r\nProgrammable FN keys via Logitech Gaming Software', 30000, 12, 18, 20, '861-20181112195227-45.png', '70'),
(66, 'LOGITECH PEBBLE KEYS 2 K380S ', 'Logitech Pebble Keys 2 K380s MultiDevice Bluetooth Wireless Keyboard with Customizable Shortcuts Slim and Portable EasySwitch for Windows macOS  iPadOS', 'Pebble Keys 2 K380s\r\nHeight 124 mm\r\nWidth 279 mm\r\nDepth 16 mm\r\nWeight with batteries 415 g\r\nTechnical Specifications\r\nSpecial features\r\nSlim lightweight minimalist design made with recycled plastic 1Pebble Keys 2 K380s plastic content minimum 49 recycled plastic excluding plastic in printed wiring assembly PWA and packaging\r\nMultidevice pairing up to 3 devices\r\nCustomizable Fn shortcut keys with Logi Options 2Available on Windows and macOS at logicomoptionsplus\r\nComfy and quiet laptoplike typing with scooped lowprofile keys\r\nKeyboard special keys', 14000, 12, 18, 50, '2337-20240116064759-pebble-keys-2-k380s-top-tonal-graphite-gallery-us (1).png', '71'),
(67, 'ASUS ROG FLARE II ANIMATE MECHANICAL KEYBOARD', 'The ASUS ROG Strix Flare II Animate is a pretty solid mechanical keyboard and it serves as a great start for those who want to tiptoe their way into the world', 'AniMe Matrix LED display Personalize and express yourself in a unique way with customizable images and animations\r\nStylish and ergonomic Detachable wrist rest with light diffuser\r\nIntuitive controls Dedicated media and volume controls are conveniently placed at the topleft corner of the keyboard\r\nAlmostinstantaneous response 8000 Hz polling rate provides a 0125 ms response time  up to 8X faster than other leading gaming keyboards\r\nAvailable with ROG NX mechanical switches Lubricated stem for smooth clicks lubricated housing to eliminate bouncing noises fast actuation and ROGtuned force curves for great keystroke feel with great keystroke consistency\r\nLearn more about ROG NX Mechanical Switches\r\nAvailable with Cherry MX mechanical switches Germanmade Cherry MX RGB mechanical switches for precision input\r\nSwappable switches Install your preferred switch type for a unique customized feel\r\nROG PBT doubleshot keycaps Durable keycaps with midheight profile and shorter stems reduce key wobble and feature translucent ROG script\r\nLearn more about ROG Doubleshot Keycap Set\r\nROG switch stabilizer Specially designed to ensure smooth keystrokes and stability for longer keys\r\nImproved acoustics Builtin sounddampening foam helps absorb pinging noises and echoes within the keyboard\r\nConvenient connectivity USB passthrough port allows for easy connection to other devices', 60000, 12, 1, 10, '2245-20230518053659-h732 (7) (1).png', '70'),
(68, 'INTEL CORE I9 PROCESSOR 14900K', 'The Intel i914900K delivers impressive performance with its high clock speeds and advanced architecture It excels in demanding tasks like gaming  content creation', 'Total Cores\r\n24\r\n\r\n of Performancecores\r\n8\r\n\r\n of Efficientcores\r\n16\r\n\r\nTotal Threads\r\n32\r\n\r\nMax Turbo Frequency\r\n6 GHz\r\n\r\nIntel Thermal Velocity Boost Frequency\r\n6 GHz\r\n\r\nIntel Turbo Boost Max Technology 30 Frequency \r\n58 GHz\r\n', 200000, 6, 8, 15, '2392-20231018180616-14900k (1).png', '44,93'),
(69, 'ASUS ROG STRIX X670E-F', 'The ROG Strix X670EF Gaming WiFi is the stealthy alter ego of the Strix X670EA A substantial power buff relays its inner demon giving exclusive ROG overclocking utilities even more headroom to unleash the potential of AMD Ryzen 7000 Series processors And its black PCB and dark metallic heatsinks aesthetically match a wider variety of system hardware and build themes while a dash of customizable color on its shroud subtly announces an ROG presence in your AM5 build', 'ROG STRIX X670EF GAMING WIFI\r\n\r\nCPU\r\nAMD Socket AM5 for AMD Ryzen 7000 Series Desktop Processors\r\n\r\n Refer to wwwasuscom for CPU support list\r\nChipset\r\nAMD X670\r\nMemory\r\n4 x DIMM Max 128GB DDR5 6400OC6200OC 6000OC 5800OC 5600OC 5400OC 5200 5000 4800 ECC andNonECC Unbuffered Memory\r\nDual Channel Memory Architecture\r\nSupports AMD EXTended Profiles for Overclocking EXPO\r\nOptiMem II\r\n Supported memory types data rateSpeed and number of DRAM module vary depending on the CPU and memory configuration for more information refer to wwwasuscom for memory support list\r\n NonECC Unbuffered DDR5 Memory supports\r\nOnDie ECC function\r\nGraphics\r\n1 x DisplayPort\r\n1 x HDMI port\r\n Supports max 8K60Hz as specified in DisplayPort 14\r\nSupports max 4K60Hz as specified in HDMI 21\r\nExpansion Slots\r\nAMD Ryzen 7000 Series Desktop Processors\r\n1 x PCIe 50 x16 slots supports x16 mode\r\nAMD X670 Chipset\r\n1 x PCIe 40 x16 slot supports x4 mode\r\n1 x PCIe 30 x1 slot\r\n Please check PCIe bifurcation table in support site httpswwwasuscomsupportFAQ1037507\r\nStorage\r\nTotal supports 4 x M2 slots and 4 x SATA 6Gbs ports\r\nAMD Ryzen 7000 Series Desktop Processors\r\nM21 slot Key M type 224222602280\r\nsupports PCIe 50 x4 mode\r\nM22 slot Key M type 224222602280\r\nsupports PCIe 50 x4 mode\r\nAMD X670 Chipset\r\nM23 slot Key M type 22422260228022110 supports PCIe 40 x4 mode\r\nM24 slot Key M type 224222602280 supports PCIe 40 x4 mode\r\n4 x SATA 6Gbs ports\r\nAMD RAIDXpert2 Technology supports both PCIe RAID 0110 and SATA RAID 0110', 185000, 1, 1, 20, '2261-20230516073127-h732 (3) (1).png', '3,8'),
(71, 'ASUS STRIX GAMING GEFORCE RTX 4090', 'The ROG Strix LC GeForce RTX 4090 channels the power of liquid cooling to unlock the GPUs full potential and then some delivering quiet thermal performance for your desktop', 'NVIDIA GeForce RTX 4090\r\nBus Standard\r\nPCI Express 40\r\nOpenGL\r\nOpenGL46\r\nVideo Memory\r\n24GB GDDR6X\r\nEngine Clock\r\nOC mode 2640 MHz\r\nGaming mode 2610 MHz Boost Clock\r\nCUDA Core\r\n16384\r\nMemory Speed\r\n21 Gbps\r\nMemory Interface\r\n384bit\r\nResolution\r\nDigital Max Resolution 7680 x 4320\r\nInterface\r\nYes x 2 Native HDMI 21a\r\nYes x 3 Native DisplayPort 14a\r\nHDCP Support Yes 23', 900000, 5, 1, 5, '1988-20221006114845-h732 (2).png', '94,42');

-- --------------------------------------------------------

--
-- Table structure for table `spces_type`
--

CREATE TABLE `spces_type` (
  `spces_type_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `spec_type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `spces_type`
--

INSERT INTO `spces_type` (`spces_type_id`, `category_id`, `spec_type_name`) VALUES
(2, 1, 'SOCKET TYPE'),
(3, 1, 'CHIPSET'),
(4, 4, 'RESOLUTION'),
(5, 4, 'SCREEN SIZE'),
(6, 4, 'PANEL TYPE'),
(7, 4, 'REFRESH RATE'),
(8, 5, 'CHIPSET'),
(9, 5, 'VRAM'),
(10, 6, 'SOCKET TYPE'),
(11, 6, 'No. Of CORES'),
(12, 7, 'PC type'),
(13, 7, 'Speed'),
(14, 7, 'Size'),
(15, 8, 'PC Type'),
(16, 8, 'INTERFACE'),
(17, 8, 'Size'),
(18, 9, 'COOLER TYPE'),
(19, 12, 'CONNECTION TYPE'),
(20, 10, 'WATTAGE'),
(21, 13, 'PROCESSOR'),
(22, 13, 'RAM'),
(23, 13, 'GPU'),
(24, 13, 'SSD');

-- --------------------------------------------------------

--
-- Table structure for table `specs`
--

CREATE TABLE `specs` (
  `id` int(11) NOT NULL,
  `specs_type_id` int(11) NOT NULL,
  `spec_name` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `specs`
--

INSERT INTO `specs` (`id`, `specs_type_id`, `spec_name`) VALUES
(2, 2, 'AMD AM4'),
(3, 2, 'AMD AM5'),
(4, 2, 'INTEL 1200'),
(5, 2, 'INTEL 1700'),
(6, 3, 'AMD B550'),
(7, 3, 'AMD B650'),
(8, 3, 'AMD X670'),
(9, 3, 'AMD X570'),
(10, 3, 'INTEL B560'),
(11, 3, 'INTEL B660'),
(14, 4, '1920 X 1080'),
(15, 4, '2560 X 1440'),
(16, 4, '4096x2160'),
(17, 5, '24'),
(18, 5, '27'),
(19, 5, '32'),
(20, 6, 'IPS'),
(21, 6, 'OLED'),
(22, 6, 'TN'),
(27, 7, '60Hz'),
(28, 7, '90Hz'),
(29, 7, '120Hz'),
(30, 7, '144Hz'),
(31, 8, 'RTX 4060'),
(32, 8, 'RTX 4080'),
(33, 8, 'RTX 4070TI'),
(38, 9, '6GB'),
(39, 9, '8GB'),
(40, 9, '12GB'),
(41, 9, '16GB'),
(42, 9, '24GB'),
(43, 10, 'SOCKET 1200'),
(44, 10, 'SOCKET 1700'),
(45, 10, 'SOCKET AM4'),
(46, 10, 'SOCKET AM5'),
(48, 11, '8'),
(49, 11, '10'),
(50, 11, '12'),
(51, 12, 'Desktop'),
(52, 12, 'Laptop'),
(53, 13, 'DDR4-3200'),
(54, 13, 'DDR4-3600'),
(55, 13, 'DDR5-5600'),
(56, 14, '8GB'),
(57, 14, '16GB'),
(58, 14, '32GB'),
(59, 15, 'Desktop'),
(60, 15, 'Laptop'),
(61, 15, 'NAS'),
(62, 16, 'M.2'),
(63, 16, 'SATA'),
(64, 17, '500GB'),
(65, 17, '1TB'),
(66, 17, '2TB'),
(67, 18, '140MM CASE FAN'),
(68, 18, 'AIR CPU COOLER'),
(69, 18, 'LIQUID COOLER'),
(70, 19, 'WIRED'),
(71, 19, 'WIRELESS'),
(72, 20, '750W'),
(73, 20, '850W'),
(74, 20, '1000W'),
(75, 20, '1200W'),
(76, 20, '1600W'),
(77, 21, 'I5'),
(78, 21, 'I7'),
(79, 21, 'I9'),
(80, 21, 'Ryzen 5'),
(81, 21, 'Ryzen 7'),
(82, 22, '8GB'),
(83, 22, '16GB'),
(84, 22, '32GB'),
(85, 23, 'RTX 4060'),
(86, 23, 'RTX 4070'),
(87, 24, '500GB'),
(88, 24, '1TB'),
(89, 11, '16'),
(90, 7, '170Hz'),
(91, 7, '240Hz'),
(92, 5, '49'),
(93, 11, '24'),
(94, 8, 'RTX 4090');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Postcode` varchar(20) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `email`, `Password`, `FirstName`, `LastName`, `Address`, `City`, `Postcode`, `Phone`, `status`) VALUES
(1, 'tanujmalinda2000@gmail.com', '123', 'tanuj', 'uduwana', '227/4 wethara,Siyamb', 'Kesbawa', '13', '0768683826', 'registered'),
(5, 'malindauduwana@gmail.com', '345', 'tanuj', 'malinda', '227/4 asdasd,asdasda', 'polgasowita', '13', '', ''),
(6, 'thira@gmail.com', '1', 'tk', 'tk', 'kulasooriya', 'cvv', '2123', '12323', 'registered'),
(7, 'thira1@gmail.com', '123456', 'Adhishtanaka', 'Kulasoooriya', '561/15/1/1', 'Kegalle', '71000', '0712689771', ''),
(8, 'thira11@gmail.com', '123456', 'f', 'f', 'f', 'f', '12', '12', 'registered'),
(9, 'tk@gmail.com', '123456', 't', 'k', 'kegalle', 'kaluthra', '6969', '0785866652', 'registered'),
(10, 'keshan@gmail.com', '1234', 'thira', 'kule', 'kegalle', 'yatiynthota', '21000', '0712689771', 'registered'),
(11, 'thira69@gmail.com', '2131', 't', 'kulasooriya', 'kottawa', 'kegalle', '21244', '0785866652', 'registered'),
(12, 'thira69696999@gmail.com', '12', 't', 'kulasooriya', 'kottawa', 'kegalle', '21244', '0785866652', 'registered'),
(14, 'tdulshan3@gmail.com', '1', 'tanuja', 'dulshan', 'kegalle', 'yatiynthota', '7100', '0712689771', 'registered'),
(15, 'kk@gmail.com', '123456', 'tk', 'kule', 'homagma', 'nuwra', '2100', '119', 'registered'),
(16, 'thira6860@gmail.com', '12', 'tikka', 'fdffdd', 'gess', 'look', '7100', '1929', 'registered'),
(17, 'dilina1000@gmail.com', '123', 'dilina', 'mewan', 'moratuwa', 'kegalle', '6700', '119', 'registered'),
(18, 'thira700@gmail.com', '1', 'tk', 'tkk', 'kkegalle', 'jaffna', '32435', '3545546', 'registered'),
(20, 'kule23@gmail.com', NULL, 'thiramithu', 'kulasooriya', 'fgh', 'dgfhd', '345', '1233', 'unregistered'),
(28, 'kule2@gmail.com', NULL, 'adhishtanaka', 'Kulasooriya', 'no:561/15/1/1', 'kegalle', '7100', '1929', 'unregistered'),
(30, 'kula@g.com', NULL, 'kule', 'tk', 'adishtanaka', 'kulasooriya', '71000', '19191', 'unregistered');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `manufacturer`
--
ALTER TABLE `manufacturer`
  ADD PRIMARY KEY (`manufacturer_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `manufacturer_id` (`manufacturer_id`);

--
-- Indexes for table `spces_type`
--
ALTER TABLE `spces_type`
  ADD PRIMARY KEY (`spces_type_id`);

--
-- Indexes for table `specs`
--
ALTER TABLE `specs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `specs_type_id` (`specs_type_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `Email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `manufacturer`
--
ALTER TABLE `manufacturer`
  MODIFY `manufacturer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `spces_type`
--
ALTER TABLE `spces_type`
  MODIFY `spces_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `specs`
--
ALTER TABLE `specs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`),
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`manufacturer_id`) REFERENCES `manufacturer` (`manufacturer_id`);

--
-- Constraints for table `specs`
--
ALTER TABLE `specs`
  ADD CONSTRAINT `specs_ibfk_2` FOREIGN KEY (`specs_type_id`) REFERENCES `spces_type` (`spces_type_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
